'use strict';
(() => {
  if (window.__galArchiveObserverLoaded) return;
  window.__galArchiveObserverLoaded = true;

  const CHAT_PATTERN = /^\/(?:c\/[a-zA-Z0-9-]+|g\/[^/]+\/c\/[a-zA-Z0-9-]+)\/?$/;
  const USER_SELECTOR = '[class~="group/user-message"]';
  const USER_BUBBLE_SELECTOR = '[class~="bg-user-message"]';
  // Observed light-mode player bubble rgb(232, 243, 254) = #E8F3FE.
  // CSS classes are primary; this shade is supporting evidence, never a standalone role guess.
  const USER_BUBBLE_COLOR = 'rgb(232, 243, 254)';
  const AI_SELECTOR = '[data-markdown-copy="contents"]';
  const LEGACY_SELECTOR = '[data-message-author-role]';
  const path = () => location.pathname.replace(/\/$/, '');
  const valid = () => CHAT_PATTERN.test(location.pathname);

  const state = { enabled: false, watchedPath: null, previousPath: null, scanning: false, activeSends: 0, autoTime: false, timeBusy: false, bulk: null };
  const baselineIds = new Set();
  const delivered = new Set();
  const candidates = new Map();
  // Session observation is NOT the original authored timestamp.
  const firstSeenAt = new Map();
  const sourceTimeCache = new Map();
  const messageElements = new Map();
  // Fallback bodies are paired to the real turn, not a guessed "ChatGPT" phrase
  // occurring inside somebody's message.
  const assistantFallbackTexts = new WeakMap();
  // Both roles in one exchange share ONE timeline minute. This is a time
  // approximation requested by the owner, NOT proof of identical send times.



  // V0.6.6: Advisory scene-time hints only. Never rewrite ChatGPT authored times,
  // Firebase event identities, scan order, or the original payload text.
  function galArchiveHintSummary(messages){
    let storyTimeCount=0,skipCueCount=0;
    const previews=[];
    for(const m of messages){
      if(m?.role!=='me'||typeof m.text!=='string')continue;
      if(/made\s+in\s+heaven|做\s*愛\s*跳\s*過/i.test(m.text))skipCueCount++;
      const segments=m.text.replace(/\r\n?/g,'\n').split(/(?:^|\n)\s*他\s*[：:；”]\s*/u).slice(1);
      for(const segment of segments){
        const head=segment.split(/\n\s*(?:我|他)\s*[：:；”]\s*/u)[0].split('\n').slice(0,12).join('\n').slice(0,950);
        const date=head.match(/(?:^|\n)\s*[｜|│]?\s*(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日/u)
          ||head.match(/(?:^|\n)\s*[｜|│]?\s*(\d{4})[/-](\d{1,2})[/-](\d{1,2})(?=\D|$)/u);
        const time=head.match(/(?:^|\n)\s*[｜|│]?\s*(?:⏰|⌚|🕒|[\u{1F550}-\u{1F567}]|時間\s*[：:]?)\s*(\d{1,2})\s*[：:]\s*(\d{2})(?:[.:：](\d{1,2}))?/u);
        if(!date||!time)continue;
        const [year,month,day]=date.slice(1).map(Number);
        const hour=+time[1],minute=+time[2],second=+(time[3]||0);
        if(year<100||month<1||month>12||day<1||day>31||hour>23||minute>59||second>59)continue;
        const ms=Date.UTC(year,month-1,day,hour-8,minute,second);
        const check=new Date(ms+8*3600000);
        if(check.getUTCFullYear()!==year||check.getUTCMonth()+1!==month
          ||check.getUTCDate()!==day||check.getUTCHours()!==hour||check.getUTCMinutes()!==minute)continue;
        storyTimeCount++;
        if(previews.length<3)previews.push(year+'/'+String(month).padStart(2,'0')+'/'+String(day).padStart(2,'0')
          +' '+String(hour).padStart(2,'0')+':'+String(minute).padStart(2,'0'));
      }
    }
    return {storyTimeCount,skipCueCount,storyTimePreview:previews.join('、')};
  }

  const diagnostics = { lastCapture: null, lastUpload: null, nodeCount: 0, userCount: 0, aiCount: 0, latest: '', enabled: false, path: '', updatedAt: 0, mode: '', error: '', timeResults: '', autoTime: false, storyTimeCount: 0, skipCueCount: 0, storyTimePreview: '' };

  // Expanded ChatGPT bubbles can expose a UI-only '顯示較少' control
  // as the final text line. Strip that standalone label, never a real '...'.
  function cleanArchiveLessTail(text) {
    const raw=String(text||'').trim();
    const cleaned=raw.replace(/(?:^|\r?\n)[ \t]*顯示較少[ \t]*$/, '').trimEnd();
    return cleaned.trim()?cleaned:raw;
  }
  function cleanText(el) {
    return (el?.innerText || '').trim();
  }
  function outerUsers() {
    // The current UI nests two group/user-message elements for every user turn.
    const direct=[...document.querySelectorAll(USER_SELECTOR)]
      .filter(el => !el.parentElement?.closest(USER_SELECTOR));
    // Some ChatGPT layouts retain the bubble class but drop the wrapper.
    // A real bubble AND a conversation-turn owner are required; the screenshot
    // color alone is never enough to classify arbitrary page elements.
    const fallback=[...document.querySelectorAll(USER_BUBBLE_SELECTOR)]
      .filter(el => !el.closest(USER_SELECTOR) && !!el.closest('[data-turn-key], [data-testid^="conversation-turn-"], [data-message-author-role="user"]'))
      .filter(el => !el.parentElement?.closest(USER_BUBBLE_SELECTOR));
    const all=[...direct,...fallback];
    return all.sort((a,b)=>{
      const cmp=a.compareDocumentPosition(b);
      return cmp & Node.DOCUMENT_POSITION_FOLLOWING?-1:cmp & Node.DOCUMENT_POSITION_PRECEDING?1:0;
    });
  }
  function isUserDescendant(el){return !!el?.closest?.(`${USER_SELECTOR}, ${USER_BUBBLE_SELECTOR}`);}
  function userText(el) {
    const inner=el.matches(USER_BUBBLE_SELECTOR)?el:el.querySelector(USER_BUBBLE_SELECTOR);
    return cleanText(inner||el);
  }
  function userId(el, index) {
    const own = el.closest('[data-turn-key]');
    // data-turn-key is a stable per-turn identifier in the observed layout.
    const turnKey = own?.getAttribute('data-turn-key');
    if (turnKey) return 'user-turn:' + turnKey;
    return 'user-position:' + index;
  }
  function aiId(el, index) {
    const id = el.querySelector('[data-dil-message-id]')?.getAttribute('data-dil-message-id')
      || el.getAttribute('data-dil-message-id')
      || el.closest('[data-source-message-id]')?.getAttribute('data-source-message-id');
    if(id)return 'ai-message:' + id;
    // Older captured Markdown messages used positional IDs; preserve those
    // identities so re-backfill does not duplicate previously accepted replies.
    // Prefer stable turn IDs before DOM positions. A virtualized chat can
    // recycle the same position for DIFFERENT assistant messages when scrolling.
    const owner=el.closest('[data-turn-key]') || el.closest('[data-testid^="conversation-turn-"]');
    const stable=owner?.getAttribute('data-turn-key') || owner?.getAttribute('data-testid');
    if(stable)return 'ai-turn:' + stable;
    return 'ai-position:' + index;
  }
  function getVisibleSourceTime(el) {
    // Explicit machine-readable timestamps only. Do not infer from display order
    // or the clock at which an older message is backfilled.
    // Only read machine timestamps from this role's own message subtree.
    // A data-turn-key may hold both user AND assistant; searching the whole
    // turn would silently attach one role's timestamp to the other.
    const scope=el;
    const node=scope.querySelector('time[datetime], [data-message-created-at], [data-created-at]');
    const raw=node?.getAttribute('datetime') || node?.getAttribute('data-message-created-at') || node?.getAttribute('data-created-at');
    if(!raw || !(/\d{4}-\d{2}-\d{2}/).test(raw))return null;
    const t=Date.parse(raw);
    return Number.isFinite(t) ? new Date(t).toISOString() : null;
  }
  function withObservedTime(m,el) {
    const k=m.role+'|'+m.id;
    if(!firstSeenAt.has(k))firstSeenAt.set(k,new Date().toISOString());
    messageElements.set(k,el);
    // A composite turn may contain *both* user and assistant. Its time node
    // must not be misassigned to the fallback assistant response.
    const direct=m.fallbackComposite?null:getVisibleSourceTime(el), cached=sourceTimeCache.get(k);
    return {...m, sourceCreatedAt:cached?.value||direct||null,
      sourceTimeOrigin:cached?.origin||(direct?'dom':null),
      sourceTimePrecision:cached?.precision||(direct?'source':null),
      capturedAt:firstSeenAt.get(k)};
  }
  // Menu timestamps are rendered as text (e.g. 今天，上午5:21) only when the
  // per-message menu is open. Read them only while the associated trigger is
  // provably the same turn. Never guess seconds or use time-of-capture as source.
  const TIME_RE = /(?:今天|昨天|前天|\d{4}年\d{1,2}月\d{1,2}日|\d{1,2}月\d{1,2}日)[，,\s]*[上下午凌晨中午晚上早上]*\s*\d{1,2}[:：]\d{2}/;
  const sleep = ms => new Promise(resolve => setTimeout(resolve,ms));
  function taiwanToday() {
    const parts=Intl.DateTimeFormat('en-US',{timeZone:'Asia/Taipei',year:'numeric',month:'numeric',day:'numeric'}).formatToParts(new Date());
    const n=type=>Number(parts.find(p=>p.type===type)?.value);
    return {y:n('year'),m:n('month'),d:n('day')};
  }
  function parseMenuTime(label) {
    if(typeof label!=='string')return null;
    const compact=label.replace(/[\u200e\u200f\u202a-\u202e]/g,'').replace(/\s+/g,'').replace(/[：]/g,':');
    let y,m,d,rest;
    const now=taiwanToday();
    const rel=compact.match(/^(今天|昨天|前天)[，,]?(.*)$/);
    const full=compact.match(/^(\d{4})年(\d{1,2})月(\d{1,2})日[，,]?(.*)$/);
    const month=compact.match(/^(\d{1,2})月(\d{1,2})日[，,]?(.*)$/);
    if(rel){
      const diff=rel[1]==='今天'?0:rel[1]==='昨天'?1:2;
      const t=new Date(Date.UTC(now.y,now.m-1,now.d-diff,12));
      y=t.getUTCFullYear();m=t.getUTCMonth()+1;d=t.getUTCDate();rest=rel[2];
    }else if(full){y=+full[1];m=+full[2];d=+full[3];rest=full[4];}
    else if(month){y=now.y;m=+month[1];d=+month[2];rest=month[3];
      if(m>now.m||(m===now.m&&d>now.d))y--;
    }else return null;
    const tm=rest.match(/^(上午|下午|凌晨|中午|晚上|早上)?(\d{1,2}):(\d{2})$/);
    if(!tm)return null;
    const period=tm[1]||'',hh=+tm[2],mi=+tm[3];
    if(mi>59||hh>23)return null;
    if(period&&hh>12)return null;
    let hour=hh;
    if(period==='下午'||period==='晚上'||period==='中午')hour=(hh%12)+12;
    if(period==='上午'||period==='凌晨'||period==='早上')hour=hh===12?0:hh;
    const utc=Date.UTC(y,m-1,d,hour-8,mi,0);
    const check=new Date(utc+8*3600000);
    if(check.getUTCFullYear()!==y||check.getUTCMonth()+1!==m||check.getUTCDate()!==d||check.getUTCHours()!==hour)return null;
    if(utc>Date.now()+5*60000||utc<Date.now()-5*365*86400000)return null;
    return new Date(utc).toISOString(); // precise to the minute, NOT the second
  }
  function currentTimeItem() {
    const options=[...document.querySelectorAll('[role="menuitem"]')]
      .filter(e=>TIME_RE.test((e.innerText||'').trim()));
    return options.length===1?options[0]:null;
  }
  function openMenuTriggers() {
    return [...document.querySelectorAll('button[aria-haspopup="menu"]')]
      .filter(e=>e.getAttribute('data-state')==='open'||e.getAttribute('aria-expanded')==='true');
  }
  async function waitForMenu(button,limit=750) {
    const deadline=Date.now()+limit;
    while(Date.now()<deadline){
      if(button.getAttribute('data-state')==='open'||button.getAttribute('aria-expanded')==='true')return true;
      await sleep(35);
    }
    return false;
  }
  function pointerDown(button) {
    if(typeof PointerEvent!=='undefined')button.dispatchEvent(new PointerEvent('pointerdown',{
      bubbles:true,cancelable:true,pointerType:'mouse',isPrimary:true,button:0,buttons:1
    }));
  }
  async function closeCapturedMenu(button) {
    const opened=openMenuTriggers().includes(button);
    if(!opened)return;
    const focused=document.activeElement;
    const target=document.querySelector('[role="menu"][data-state="open"]')||focused||button;
    target.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true,cancelable:true}));
    await sleep(100);
    if(openMenuTriggers().includes(button))pointerDown(button);
  }
  function chooseMessageMenuTrigger(owner, m) {
    // A turn may contain several menu buttons (e.g. the user's edit menu,
    // assistant action menus or embedded tools). Never pick the first blindly.
    const all=[...owner.querySelectorAll('button[aria-haspopup="menu"]')]
      .filter(b=>b.closest('[data-turn-key]')===owner);
    if(!all.length)return {reason:'沒有找到訊息選單按鈕'};
    const isVisible=b=>b.getClientRects().length>0;
    const visible=all.filter(isVisible);
    const pool=visible.length?visible:all;
    const isMore=b=>/^(more|more options|更多|更多選項|其他選項|其他操作|⋯|\.\.\.)$/i.test(
      [b.getAttribute('aria-label'),b.getAttribute('title'),b.getAttribute('data-testid'),b.innerText]
        .filter(Boolean).join(' ').trim()
    ) || /more|更多|ellipsis/i.test(
      [b.getAttribute('aria-label'),b.getAttribute('title'),b.getAttribute('data-testid')]
        .filter(Boolean).join(' ')
    );
    const actionRows=[...owner.querySelectorAll('.turn-action-controls, [class*="turn-action-controls"]')];
    const inAction=pool.filter(b=>actionRows.some(row=>row.contains(b)));
    const narrowed=inAction.length?inAction:pool;
    // An already open trigger is the strongest available association.
    const opened=narrowed.filter(b=>b.getAttribute('data-state')==='open'||b.getAttribute('aria-expanded')==='true');
    if(opened.length===1)return {button:opened[0]};
    if(opened.length>1)return {reason:'目標回合有多個已開啟選單'};
    const more=narrowed.filter(isMore);
    if(more.length===1)return {button:more[0]};
    if(narrowed.length===1)return {button:narrowed[0]};
    // For a composite user+GPT turn, two message-action triggers appear in
    // chronological order. Prefer GPT's later trigger. Still reject 3+.
    if(narrowed.length===2 && owner.querySelector(USER_SELECTOR))
      return {button:m.role==='ai'?narrowed[1]:narrowed[0]};
    return {reason:`目標回合有 ${all.length} 個選單按鈕，無法安全辨識訊息選單（動作列 ${inAction.length} 個）`};
  }
  async function captureMenuTime(m,{preserveOpened=false}={}) {
    if(state.timeBusy)return {ok:false,reason:'正在擷取另一則'};
    const k=keyOf(m),el=messageElements.get(k),owner=el?.closest('[data-turn-key]');
    if(!owner)return {ok:false,reason:'找不到所屬回合'};
    // Composite turn is not an error: once a valid per-turn menu time is read,
    // it is shared with the paired player/GPT entry with clear provenance.
    const choice=chooseMessageMenuTrigger(owner,m);
    if(!choice.button)return {ok:false,reason:choice.reason};
    const button=choice.button;
    const previouslyOpen=openMenuTriggers();
    if(previouslyOpen.length&&!(previouslyOpen.length===1&&previouslyOpen[0]===button))return {ok:false,reason:'使用者正在操作其他選單'};
    const owned=previouslyOpen.includes(button);
    state.timeBusy=true;
    try{
      if(!owned){
        // Radix menu triggers may listen to pointerdown rather than click.
        pointerDown(button);
        if(!await waitForMenu(button,450)){
          button.click();
          if(!await waitForMenu(button,600))return {ok:false,reason:'自動打開選單失敗'};
        }
      }
      await sleep(100);
      const active=openMenuTriggers();
      if(active.length!==1||active[0]!==button)return {ok:false,reason:'無法確認開啟的是目標訊息'};
      const item=currentTimeItem();
      if(!item)return {ok:false,reason:'選單沒有可辨識的時間'};
      const text=item.innerText.trim();
      const iso=parseMenuTime(text);
      if(!iso)return {ok:false,reason:'日期格式不支援：'+text.slice(0,48)};
      // This turn key was verified with the trigger and opened menu.
      sourceTimeCache.set(k,{value:iso,origin:'menu',precision:'minute',turnKey:owner.getAttribute('data-turn-key')});
      const partner=pairForMessage(m);
      if(partner){
        const pk=keyOf(partner);
        sourceTimeCache.set(pk,{value:iso,origin:'reply-inferred',precision:'minute-estimated',
          pairedWith:k,turnKey:owner.getAttribute('data-turn-key')});
      }
      recordCapture({status:'success',role:m.role,preview:m.text.slice(0,65),sourceCreatedAt:iso,sourceTimeOrigin:'menu',sourceTimePrecision:'minute',paired:!!partner,detail:text+(partner?'；同一回合的另一方共用此分鐘（推定）':'')});
      return {ok:true,iso,text,turnKey:owner.getAttribute('data-turn-key'),preview:m.text.slice(0,65),paired:!!partner};
    }finally{
      if(!owned&&!preserveOpened)await closeCapturedMenu(button);
      state.timeBusy=false;
    }
  }
  function saveTimeEvent(globalKey,byChatKey,result){
    // Keep each conversation's latest timestamp independent from other cycles.
    const chat=result.chat;
    chrome.storage.local.get([byChatKey], data=>{
      const map=data[byChatKey]||{};
      map[chat]=result;
      const recent=Object.entries(map).sort((a,b)=>String(b[1]?.at||'').localeCompare(String(a[1]?.at||''))).slice(0,150);
      chrome.storage.local.set({[globalKey]:result,[byChatKey]:Object.fromEntries(recent)});
    });
  }
  function recordCapture(result) {
    diagnostics.lastCapture={...result,chat:path(),at:new Date().toISOString()};
    saveTimeEvent('lastTimeCapture','lastTimeCaptureByChat',diagnostics.lastCapture);
  }
  function pairedIndex(messages,index){
    if(index<0 || index>=messages.length)return -1;
    const m=messages[index];
    const j=m.role==='me'?index+1:index-1;
    if(j<0||j>=messages.length)return -1;
    const partner=messages[j];
    if(!partner || partner.role===m.role || (m.role==='me'&&partner.role!=='ai') ||
       (m.role==='ai'&&partner.role!=='me'))return -1;
    // They must be an adjacent user→assistant exchange; a shared turn owner
    // is even stronger evidence. Never pair across any intervening message.
    return j;
  }
  function sharedCapturedMinute(messages){
    // If the original date is unknown, both sides of the exchange use exactly
    // the same first-observed time for sorting; it remains capturedAt, not a
    // fictitious original message timestamp.
    for(let i=0;i<messages.length-1;i++){
      const u=messages[i],a=messages[i+1];
      if(u.role!=='me'||a.role!=='ai')continue;
      const uk=keyOf(u),ak=keyOf(a);
      const both=[Date.parse(u.capturedAt),Date.parse(a.capturedAt)].filter(Number.isFinite);
      if(both.length){
        const shared=new Date(Math.min(...both)).toISOString();
        firstSeenAt.set(uk,shared); firstSeenAt.set(ak,shared);
        u.capturedAt=shared;a.capturedAt=shared;
      }
      const uc=sourceTimeCache.get(uk),ac=sourceTimeCache.get(ak);
      // Explicit menu time > shared guess. GPT's own menu wins if both are
      // independently known; otherwise use the available side.
      const sources=[
        {role:'ai',item:ac},{role:'me',item:uc},
        {role:'ai',item:a.sourceCreatedAt?{value:a.sourceCreatedAt,origin:a.sourceTimeOrigin||'dom',precision:a.sourceTimePrecision||'source'}:null},
        {role:'me',item:u.sourceCreatedAt?{value:u.sourceCreatedAt,origin:u.sourceTimeOrigin||'dom',precision:u.sourceTimePrecision||'source'}:null}
      ].filter(x=>x.item?.value);
      sources.sort((x,y)=>{
        const grade=x=>(x.item.origin==='menu'||x.item.origin==='dom'?3:
          x.item.origin==='reply-inferred'?1:2)*10+(x.role==='ai'?1:0);
        return grade(y)-grade(x);
      });
      const chosen=sources[0];
      if(!chosen)continue;
      const item=chosen.item;
      for(const member of [u,a]){
        const k=keyOf(member);
        const same=member.role===chosen.role;
        const origin=same?item.origin:'reply-inferred';
        const precision=same?item.precision:'minute-estimated';
        const next={value:item.value,origin,precision,
          pairedWith:member.role==='me'?ak:uk};
        sourceTimeCache.set(k,next);
        member.sourceCreatedAt=next.value;member.sourceTimeOrigin=next.origin;
        member.sourceTimePrecision=next.precision;
      }
    }
    return messages;
  }
  function pairForMessage(m){
    const list=collect(),index=list.findIndex(x=>keyOf(x)===keyOf(m));
    const j=pairedIndex(list,index);
    return j>=0?list[j]:null;
  }
  // A reply may be plain Markdown, a DIL renderer, or an older assistant
  // container.  Finding one user bubble does NOT prove that all assistant
  // replies are marked with data-markdown-copy; never silently drop them.
  const AI_BODY_SELECTORS = [
    '[data-dil-message-id]',
    '[data-markdown-copy="contents"]',
    '[data-message-author-role="assistant"]',
    '[data-testid="assistant-message"]',
    '.markdown',
    '[class~="prose"]'
  ];
  const AI_CANDIDATE_SELECTOR = AI_BODY_SELECTORS.slice(0,4).join(',');
  const TURN_SELECTOR = '[data-turn-key], [data-testid^="conversation-turn-"]';
  function closestTurn(el) {
    return el.closest('[data-turn-key]') || el.closest('[data-testid^="conversation-turn-"]')
      || el.closest('[data-message-author-role="assistant"]') || el;
  }
  function isUserContainer(el) {
    return el.matches(USER_SELECTOR) || el.matches(USER_BUBBLE_SELECTOR) || !!el.querySelector(USER_SELECTOR+', '+USER_BUBBLE_SELECTOR);
  }
  function bestAssistantBody(container) {
    // Prefer a complete reply renderer over its nested individual text spans.
    // On legacy pages choose the Markdown subtree, not action buttons.
    for (const selector of AI_BODY_SELECTORS) {
      if (container.matches?.(selector)) {
        if(selector==='[data-message-author-role="assistant"]') {
          const inner=container.querySelector('[data-dil-message-id], [data-markdown-copy="contents"], .markdown, [class~="prose"]');
          return inner || container;
        }
        return container;
      }
      const candidate=container.querySelector(selector);
      if (candidate) {
        if(selector==='[data-message-author-role="assistant"]') {
          return candidate.querySelector('[data-dil-message-id], [data-markdown-copy="contents"], .markdown, [class~="prose"]') || candidate;
        }
        return candidate;
      }
    }
    return null; // Don't copy arbitrary action/control text as a GPT message.
  }
  // Some recent ChatGPT responses (especially DIL/plain text) have neither
  // data-markdown-copy nor a data-dil-message-id.  The turn, however, still
  // contains the *actual* user bubble plus assistant text later in the DOM.
  // Reconstruct the assistant part strictly from rendered text OUTSIDE the
  // user bubble. Never infer assistant status merely from the words it says.
  const FALLBACK_SKIP = 'button, [role="button"], [role="menu"], nav, footer, script, style, textarea, input, select, svg, [aria-hidden="true"], [hidden], [contenteditable="true"], .sr-only, [class*="sr-only"], .turn-action-controls, [class*="turn-action-controls"]';
  const RESPONSE_LABEL = /^(?:ChatGPT\s*(?:說|said)|你說|You said|Assistant)\s*[:：]?$/i;
  function assistantTextWithoutUser(owner, userBoundary) {
    // Only visible DOM text *after* the user bubble may count as an answer.
    // This also works when the assistant and user share one data-turn-key.
    // A different-turn fallback is intentionally conservative.
    const walker=document.createTreeWalker(owner,NodeFilter.SHOW_TEXT);
    let node, chunks=[],lastBlock=null,total=0;
    while((node=walker.nextNode())!==null){
      const parent=node.parentElement,raw=node.nodeValue||'';
      if(!parent||!raw.trim())continue;
      if(userBoundary && !(userBoundary.compareDocumentPosition(node)&Node.DOCUMENT_POSITION_FOLLOWING))continue;
      if(isUserDescendant(parent) || parent.closest(FALLBACK_SKIP))continue;
      if(parent.closest('[data-testid="conversation-turn-tools"], [data-testid="turn-actions"]'))continue;
      if(RESPONSE_LABEL.test(raw.trim()))continue;
      // Hidden/portal menu labels are not assistant content.
      if(parent.closest('[data-radix-popper-content-wrapper]'))continue;
      if(parent.getClientRects().length===0)continue;
      const block=parent.closest('p, pre, li, blockquote, h1, h2, h3, h4, h5, h6, tr, article, section')||parent.closest('div');
      if(lastBlock&&block&&lastBlock!==block)chunks.push('\n');
      chunks.push(raw);lastBlock=block||parent;total+=raw.length;
      if(total>30000)break;
    }
    let text=chunks.join('').replace(/\n[ \t]+/g,'\n').replace(/[ \t]+\n/g,'\n').replace(/\n{4,}/g,'\n\n\n').trim();
    // Controls from truncated replies may be hidden from the text walk, but
    // expandButtons(owner) / isCollapsed will still stop premature archiving.
    return text;
  }
  function assistantElements() {
    const replies=new Map();
    const add=el=>{
      if(!el || isUserDescendant(el))return;
      const owner=closestTurn(el);
      // Do not reject an explicit GPT body just because the turn also has a user.
      // The marker itself must be outside the user's bubble.
      let body=bestAssistantBody(el);
      if(!body || isUserDescendant(body)) {
        body=AI_BODY_SELECTORS.flatMap(selector=>[...owner.querySelectorAll(selector)])
          .find(x=>!isUserDescendant(x))||null;
      }
      if(!body||isUserDescendant(body)||!cleanText(body))return;
      const previous=replies.get(owner);
      if(!previous || cleanText(body).length>cleanText(previous).length)replies.set(owner,body);
    };
    const owners=[...document.querySelectorAll(TURN_SELECTOR)]
      .filter(owner=>!owner.parentElement?.closest(TURN_SELECTOR));
    for(const owner of owners)add(owner);
    for(const el of document.querySelectorAll(AI_CANDIDATE_SELECTOR))add(el);
    let fallbackCount=0, ambiguousCount=0;
    for(const owner of owners){
      if(replies.has(owner))continue;
      const userBubbles=outerUsers().filter(el=>owner.contains(el));
      if(userBubbles.length!==1){
        // Without exactly one marked user bubble, we cannot safely split a
        // composite turn; don't let other page UI become a reply.
        if(userBubbles.length>1)ambiguousCount++;
        continue;
      }
      const text=assistantTextWithoutUser(owner,userBubbles[0]);
      if(!text || text.length<2){ambiguousCount++;continue;}
      // Ensure this was not just a toolbar/time label or a collapsed preview.
      if(/^(?:Copy|Share|Retry|複製|分享|重試|編輯|更多選項|顯示較多|顯示更多|你說|ChatGPT 說|\d{1,2}:\d{2})$/i.test(text)){
        ambiguousCount++;continue;
      }
      assistantFallbackTexts.set(owner,text);
      replies.set(owner,owner);fallbackCount++;
    }
    diagnostics.fallbackAiCount=fallbackCount;
    diagnostics.ambiguousTurns=ambiguousCount;
    return [...replies.values()];
  }
  // ChatGPT folds lengthy bubbles behind "... / 顯示較多".  That is a UI
  // control, not part of a story. Never upload the truncated preview as canon.
  const EXPAND_LABEL=/^(?:顯示較多|顯示更多|顯示全部|展開全文|Show more|Read more)$/i;
  const TRUNCATED_TAIL=/(?:^|\n)\s*(?:(?:\.{3}|…|⋯)\s*(?:\n\s*)?)?(?:顯示較多|顯示更多|顯示全部|展開全文|Show more|Read more)\s*$/i;
  const attempts=new WeakSet();
  function turnForMessage(m) {
    const el=messageElements.get(keyOf(m));
    return el?.closest('[data-turn-key], [data-testid^="conversation-turn-"]') || el?.closest(USER_SELECTOR) || el;
  }
  function expandButtons(owner) {
    if(!owner)return [];
    const hits=[...owner.querySelectorAll('button, [role="button"], a, [tabindex]')].filter(el=>{
      const label=(el.innerText||el.textContent||el.getAttribute('aria-label')||'').trim();
      return EXPAND_LABEL.test(label);
    });
    if(hits.length)return hits;
    // Older ChatGPT builds use a cursor-pointer span/div instead of a button.
    return [...owner.querySelectorAll('span, div')].filter(el=>{
      if(el.children.length && [...el.children].some(x=>(x.innerText||'').trim()===(el.innerText||'').trim()))return false;
      if(!EXPAND_LABEL.test((el.innerText||'').trim()))return false;
      return el.matches('[class*="cursor-pointer"], [class*="cursor-interaction"]');
    });
  }
  function isCollapsed(m) {
    return TRUNCATED_TAIL.test((m.text||'').replace(/\r\n?/g,'\n')) || expandButtons(turnForMessage(m)).length>0;
  }
  async function expandCollapsed(maxClicks=4) {
    let opened=0,failed=0;
    for(const m of collect()){
      if(opened>=maxClicks)break;
      const buttons=expandButtons(turnForMessage(m));
      if(!buttons.length)continue;
      const button=buttons.find(el=>!attempts.has(el));
      if(!button)continue;
      attempts.add(button);
      try{
        button.click();
        opened++;
        await sleep(120);
      }catch(e){failed++;console.warn('輪迴歸檔：展開長訊息失敗',e)}
    }
    if(opened||failed)diagnostics.expansionStatus=`已嘗試展開 ${opened} 則長訊息${failed?'；失敗 '+failed+' 則':''}`;
    return opened;
  }
  function newLayout() {
    const users=outerUsers();
    const assistant=assistantElements();
    const tagged=new Map();
    for(const el of users)tagged.set(el,'me');
    for(const el of assistant)tagged.set(el,'ai');
    const els=[...tagged.keys()].sort((a,b)=>{
      if(a===b)return 0;
      // When one data-turn-key owns both messages, the fallback assistant
      // points at the ancestor turn. It must still follow the user message.
      const aOwner=a.closest('[data-turn-key]'),bOwner=b.closest('[data-turn-key]');
      if(aOwner && aOwner===bOwner && tagged.get(a)!==tagged.get(b))
        return tagged.get(a)==='me'?-1:1;
      const cmp=a.compareDocumentPosition(b);
      return cmp & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : cmp & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
    });
    const output=[];
    let ui=0,ai=0;
    for(const el of els){
      const user=tagged.get(el)==='me', index=user?ui++:ai++;
      const fallback=!user&&assistantFallbackTexts.has(el);
      const text=cleanArchiveLessTail(user?userText(el):fallback?assistantFallbackTexts.get(el):cleanText(el));
      if(!text)continue;
      output.push(withObservedTime({id:user?userId(el,index):aiId(el,index),role:user?'me':'ai',text,order:output.length,fallbackComposite:fallback},el));
    }
    return sharedCapturedMinute(output);
  }
  function oldLayout() {
    const nodes = [...document.querySelectorAll(LEGACY_SELECTOR)]
      .filter(el => ['user','assistant'].includes(el.getAttribute('data-message-author-role')))
      .filter(el => !el.parentElement?.closest(LEGACY_SELECTOR));
    return sharedCapturedMinute(nodes.map((el, i) => {
      const user = el.getAttribute('data-message-author-role') === 'user';
      const body = user ? (el.querySelector('.whitespace-pre-wrap') || el) : (el.querySelector('.markdown') || el);
      return withObservedTime({
        id: 'legacy:' + (el.getAttribute('data-message-id') || el.closest('[data-message-id]')?.getAttribute('data-message-id') || i),
        role: user ? 'me' : 'ai',
        text: cleanArchiveLessTail(cleanText(body)),
        order: i
      },el);
    }));
  }
  function collect() {
    const newer = newLayout();
    if(newer.length){
      const legacy=oldLayout();
      // When only the user side is marked in the new layout, collect legacy
      // assistant nodes too.  Prefer the new turn-key record if both exist.
      const included=new Set(newer.filter(x=>x.role==='ai').map(x=>x.text));
      const missing=legacy.filter(m=>m.role==='ai' && !included.has(m.text));
      if(missing.length){
        const combined=[...newer,...missing].sort((a,b)=>{
          const x=messageElements.get(keyOf(a)),y=messageElements.get(keyOf(b));
          if(x===y)return a.role==='me'?-1:1;
          const tx=x?.closest?.('[data-turn-key], [data-testid^="conversation-turn-"]');
          const ty=y?.closest?.('[data-turn-key], [data-testid^="conversation-turn-"]');
          if(tx && tx===ty && a.role!==b.role)return a.role==='me'?-1:1;
          const relation=x?.compareDocumentPosition?.(y)||0;
          return relation & Node.DOCUMENT_POSITION_FOLLOWING?-1:relation & Node.DOCUMENT_POSITION_PRECEDING?1:0;
        });
        combined.forEach((m,i)=>{m.order=i});
        diagnostics.mode='混合新版／舊版 GPT 相容';
        return combined;
      }
      diagnostics.mode='新版 ChatGPT（含 DIL／Markdown／無標記文字備援）';
      return newer;
    }
    diagnostics.mode='舊版相容模式';
    return oldLayout();
  }
  function keyOf(m) { return m.role + '|' + m.id; }
  function noteStatus() {
    const messages = collect();
    diagnostics.nodeCount = messages.length;
    diagnostics.userCount = messages.filter(m => m.role === 'me').length;
    diagnostics.aiCount = messages.filter(m => m.role === 'ai').length;
    diagnostics.assistantMarkers = document.querySelectorAll(AI_CANDIDATE_SELECTOR).length;
    diagnostics.turnCount = document.querySelectorAll('[data-turn-key]').length;
    diagnostics.collapsedCount=messages.filter(isCollapsed).length;
    // Counts refer only to currently rendered ChatGPT bubbles, not full history.
    Object.assign(diagnostics,galArchiveHintSummary(messages));
    diagnostics.detectWarning = diagnostics.userCount>=2 && diagnostics.aiCount===0
      ?'⚠ 偵測到多則玩家訊息，卻沒有辨識到 GPT 回覆。暫停回補及發送，請確認頁面結構。':'';
    diagnostics.enabled = state.enabled;
    diagnostics.path = path();
    diagnostics.updatedAt = Date.now();
    diagnostics.latest = messages.length ? messages[messages.length-1].role + ': ' + messages[messages.length-1].text.slice(0,42) : '找不到可辨認的訊息';
    return messages;
  }
  function baseline() {
    baselineIds.clear();
    firstSeenAt.clear();
    delivered.clear();
    candidates.clear();
    sourceTimeCache.clear();
    messageElements.clear();
    for (const m of noteStatus()) baselineIds.add(keyOf(m));
  }
  async function syncWatch() {
    const p = path();
    if (p !== state.previousPath) {
      state.previousPath = p;
      state.watchedPath = null;
      state.enabled = false;
      baseline();
    }
    if (!valid()) return;
    const { watch = {}, autoTimeCapture = false } = await chrome.storage.local.get(['watch','autoTimeCapture']);
    state.autoTime=autoTimeCapture===true;
    diagnostics.autoTime=state.autoTime;
    const enabled = watch[p] === true;
    if (enabled && state.watchedPath !== p) {
      baseline();
      state.watchedPath = p;
    }
    state.enabled = enabled;
    if (!enabled) { state.watchedPath = null; candidates.clear(); }
  }
  function isGenerating() {
    return !!document.querySelector('[data-testid="stop-button"], button[aria-label="Stop generating"], button[aria-label="停止生成"], button[aria-label="停止產生"]');
  }
  function sendMessage(m, k, current) {
    const messageChat=path();
    current.sending = true;
    state.activeSends++;
    chrome.runtime.sendMessage({ type: 'queue-message', identity: m.id, role: m.role, text: m.text, order: m.order, sourceCreatedAt: m.sourceCreatedAt, sourceTimeOrigin: m.sourceTimeOrigin, sourceTimePrecision: m.sourceTimePrecision, capturedAt: m.capturedAt }, result => {
      state.activeSends = Math.max(0, state.activeSends - 1);
      const err = chrome.runtime.lastError?.message;
      if (err || !result?.ok) {
        diagnostics.error = err || result?.error || '無法寫入 Firebase';
        diagnostics.lastUpload={ok:false,chat:messageChat,role:m.role,preview:m.text.slice(0,48),sourceCreatedAt:m.sourceCreatedAt,sourceTimeOrigin:m.sourceTimeOrigin,error:diagnostics.error,at:new Date().toISOString()};
        saveTimeEvent('lastTimeUpload','lastTimeUploadByChat',diagnostics.lastUpload);
        current.sending = false;
        current.retryAfter = Date.now() + 15000;
        return;
      }
      diagnostics.error = '';
      diagnostics.lastUpload={ok:true,chat:messageChat,role:m.role,preview:m.text.slice(0,48),sourceCreatedAt:m.sourceCreatedAt,sourceTimeOrigin:m.sourceTimeOrigin,at:new Date().toISOString(),duplicate:!!result?.duplicate};
      saveTimeEvent('lastTimeUpload','lastTimeUploadByChat',diagnostics.lastUpload);
      delivered.add(k);
      candidates.delete(k);
    });
  }
  async function scan() {
    // Historical range import has a separate, sequential uploader. Do not let
    // the ordinary observer race it or secretly upload outside its boundaries.
    if (state.bulk || !valid() || !state.enabled || state.watchedPath !== path()) return;
    const now = Date.now();
    await expandCollapsed(4);
    const messages = noteStatus();
    if(diagnostics.detectWarning){diagnostics.error=diagnostics.detectWarning;return}
    const streaming = isGenerating();
    for (const m of messages) {
      const k = keyOf(m);
      if (baselineIds.has(k) || delivered.has(k) || !m.text) continue;
      // A player turn is only safe to archive together with a recognized GPT
      // response. Do not write an unanswered player turn, including mid-stream.
      const pairAt=messages.findIndex(x=>keyOf(x)===k);
      if (pairedIndex(messages,pairAt)<0 || streaming) continue;
      if(isCollapsed(m)){diagnostics.error='有未展開的長訊息，禁止寫入不完整內容。請檢查「顯示較多」並再次回補。';continue}
      // Avoid uploading a message while its text is still changing.
      if (m.text.length > 25000) { diagnostics.error = '訊息超過 25000 字元，暫不歸檔'; continue; }
      let candidate = candidates.get(k);
      if (!candidate || candidate.text !== m.text) {
        candidate = {text:m.text, lastChanged:now, sending:false, retryAfter:0};
        candidates.set(k, candidate);
        continue;
      }
      if (candidate.sending || now < candidate.retryAfter) continue;
      if (streaming && m.role === 'ai') continue;
      if (now - candidate.lastChanged < (m.role === 'ai' ? 6000 : 2000)) continue;
      if (state.activeSends >= 1) continue; // Keep import ordering and avoid burst requests.
      if(state.autoTime&&!candidate.timeAttempted&&!sourceTimeCache.has(k)){
        if(streaming)continue; // Avoid opening menus during generation.
        const pos=messages.findIndex(x=>keyOf(x)===k);
        const paired=pairedIndex(messages,pos);
        const preferred=paired>=0&&m.role==='me'?messages[paired]:m;
        // If the matching GPT reply exists and is still settling, don't grab
        // the player's menu instead of its newer reply time.
        if(preferred.role==='ai'&&Date.now()-Date.parse(preferred.capturedAt)<6000)continue;
        candidate.timeAttempted=true;
        let stamp=await captureMenuTime(preferred);
        if(!stamp.ok && preferred!==m)stamp=await captureMenuTime(m);
        diagnostics.timeResults=stamp.ok?`取得 ${stamp.preview}：${stamp.text}${stamp.paired?'（已套用同回合雙方）':''}`:`未取得 ${m.text.slice(0,18)}：${stamp.reason}`;
        if(!stamp.ok)recordCapture({status:'failed',role:m.role,preview:m.text.slice(0,65),detail:stamp.reason});
        if(!stamp.ok && /使用者正在操作|正在擷取另一則/.test(stamp.reason)){
          candidate.timeAttempted=false;
          candidate.retryAfter=Date.now()+1800;
          continue;
        }
      }
      // If no menu timestamp was readable, wait briefly for the next GPT
      // response so both parts share one first-observed ordering timestamp.
      if(state.autoTime && m.role==='me' && !sourceTimeCache.has(k)
          && Date.now()-candidate.lastChanged<90000)continue;
      if(!valid()||!state.enabled||state.watchedPath!==path()||candidate.text!==m.text)continue;
      const newer=collect().find(x=>keyOf(x)===k);
      if(newer&&isCollapsed(newer)){diagnostics.error='長訊息仍未展開，略過本則以保護正史';continue}
      if(!newer || newer.text!==candidate.text){
        candidate.lastChanged=Date.now();
        candidate.text=newer?.text||'';
        candidate.timeAttempted=false;
        continue;
      }
      sendMessage(newer, k, candidate);
    }
  }

  // V0.6.0: gap-proof slow traversal and bidirectional pair verification.
  // No remote ChatGPT history API is used. Only actual rendered message DOM is
  // read, and we never send a player turn until its GPT partner is present.
  const BULK_LIMIT=4000;             // explicit stop, never silently truncate
  const BULK_MAX_DURATION=1500000;    // slow scans need time; still have an upper bound
  const BULK_SCROLL_RATIO=0.27;       // <=27% viewport each step; keep overlap checks
  const BULK_SCROLL_DELAY=477;       // let virtualized turns render before continuing
  const BULK_SETTLE_DELAY=340;       // stabilization after expanding/time popovers
  const BULK_SELECTOR='[data-turn-key], [data-testid^="conversation-turn-"]';
  const BULK_STYLE_ID='ga-archive-range-style';
  let bulkLastStoredAt=0;
  const isBulkLive=b=>state.bulk===b&&!b.cancelled&&valid()&&state.enabled&&state.watchedPath===b.chat&&path()===b.chat;
  function bulkNode(m) {return messageElements.get(keyOf(m))||null;}
  function bulkTurn(m) {return bulkNode(m)?.closest(BULK_SELECTOR)||null;}
  function bulkIdentity(m) {
    const owner=bulkTurn(m);
    const stable=owner?.getAttribute('data-turn-key')||owner?.getAttribute('data-testid');
    if(stable)return m.role+'|turn:'+stable;
    if(/^(?:ai-message:|user-turn:|legacy:|ai-turn:)/.test(m.id))return m.role+'|'+m.id;
    return null; // recycled positional DOM IDs are unsafe for historical scans
  }
  function bulkSendIdentity(m) {
    if(!/^(ai-position:|user-position:)/.test(m.id))return m.id;
    return m.role==='ai'?'ai-turn:'+m.bulkKey.split('|turn:').at(-1):'user-turn:'+m.bulkKey.split('|turn:').at(-1);
  }
  function bulkHost() {
    const first=outerUsers()[0]||document.querySelector(BULK_SELECTOR);
    for(let p=first;p&&p!==document.body;p=p.parentElement){
      const css=getComputedStyle(p);
      if(p.clientHeight>180&&p.scrollHeight>p.clientHeight+80&&/(auto|scroll|overlay)/.test(css.overflowY))return p;
    }
    const alternatives=[...document.querySelectorAll('main, [class*="overflow-y-auto"], [class*="overflow-auto"], [data-scroll-root]')]
      .filter(p=>p.contains(first)&&p.clientHeight>180&&p.scrollHeight>p.clientHeight+80)
      .sort((a,b)=>a.clientHeight-b.clientHeight);
    return alternatives[0]||document.scrollingElement||document.documentElement;
  }
  function bulkPosition(host){return host.scrollTop||0;}
  function bulkViewport(host){
    if(host===document.scrollingElement||host===document.documentElement||host===document.body)return {top:0,bottom:innerHeight};
    const r=host.getBoundingClientRect();
    return {top:Math.max(0,r.top),bottom:Math.min(innerHeight,r.bottom)};
  }
  function bulkVisible(m,host){
    const el=bulkNode(m);if(!el)return false;
    const r=el.getBoundingClientRect(),v=bulkViewport(host);
    return r.height>0&&r.bottom>v.top+5&&r.top<v.bottom-5;
  }
  function bulkFirstAtViewport(host){
    const list=collect();
    const visible=list.find(m=>bulkVisible(m,host)&&bulkIdentity(m));
    if(!visible)return null;
    const i=list.findIndex(x=>bulkIdentity(x)===bulkIdentity(visible));
    // If the visible message is GPT, bring its immediately preceding player
    // turn into the selected range (a complete exchange). If inaccessible,
    // begin at the next rendered player turn instead.
    if(visible.role==='ai') {
      const prior=pairedIndex(list,i);
      if(prior>=0)return list[prior];
      return list.slice(i+1).find(m=>m.role==='me'&&bulkIdentity(m))||null;
    }
    return visible;
  }
  function bulkStatus(b,message,{error=false,force=false}={}){
    b.message=message;
    const pane=b.pane;
    if(pane){
      const info=pane.querySelector('[data-ga-status]');
      if(info){info.textContent=message;info.style.color=error?'#ffc2cc':'#e9eeff';}
    }
    diagnostics.bulkStatus={mode:b.mode,phase:b.phase,progress:message,count:b.rows.length,uploaded:b.uploaded,at:new Date().toISOString(),error};
    if(force||Date.now()-bulkLastStoredAt>1000){
      bulkLastStoredAt=Date.now();
      chrome.storage.local.get(['bulkByChat'],data=>{
        const map=data.bulkByChat||{};
        map[b.chat]=diagnostics.bulkStatus;
        chrome.storage.local.set({bulkByChat:map});
      });
    }
  }
  function bulkFinish(b,message,error=false){
    b.phase='finished';
    bulkDetachSelection(b);
    bulkStatus(b,message,{error,force:true});
    if(b.pane){
      b.pane.querySelector('[data-ga-cancel]').textContent='關閉';
      b.pane.querySelector('[data-ga-submit]').hidden=true;
      b.pane.querySelector('[data-ga-caption]').textContent='已結束。原本的訊息監看仍維持原設定。';
    }
    if(state.bulk===b)state.bulk=null;
  }
  function bulkPanel(b){
    document.getElementById(BULK_STYLE_ID)?.remove();
    document.getElementById('ga-archive-batch')?.remove();
    const style=document.createElement('style');style.id=BULK_STYLE_ID;
    style.textContent=`
      #ga-archive-batch {position:fixed!important;z-index:2147483646!important;top:12px;right:12px;
        width:min(375px,calc(100vw - 24px));padding:14px;border:2px solid #a29bfe;border-radius:13px;
        background:#10182a!important;color:#f3f4ff!important;font:13px/1.65 system-ui,sans-serif!important;
        box-shadow:0 14px 50px #0009!important}
      #ga-archive-batch * {box-sizing:border-box}
      #ga-archive-batch button{font:inherit!important;cursor:pointer!important;border-radius:8px!important;
        border:1px solid #6873ac!important;background:#34486e!important;color:white!important;
        padding:7px 10px!important;margin:5px 5px 0 0!important}
      #ga-archive-batch button[data-ga-submit]{background:#4d50cb!important}
      [data-ga-archive-hover="true"]{outline:3px solid #ffdb73!important;outline-offset:3px!important}
      [data-ga-archive-selected="true"]{outline:3px solid #9b93ff!important;outline-offset:3px!important}
    `;
    document.documentElement.appendChild(style);
    const pane=document.createElement('section');pane.id='ga-archive-batch';pane.setAttribute('role','status');
    const title=document.createElement('div');title.style.fontWeight='750';title.style.fontSize='15px';
    title.textContent=b.mode==='down'?'📥 從目前位置向下掃描':'🖱️ 拖曳／點選對話範圍';
    const caption=document.createElement('div');caption.dataset.gaCaption='';
    caption.textContent=b.mode==='down'?'正在沿頁面向下收集完整的玩家＋副駕駛回合。':'先點選起點，再捲動或拖動畫面，點選終點；也可按住訊息向下拖曳選取。';
    const status=document.createElement('div');status.dataset.gaStatus='';status.style.marginTop='6px';status.textContent='準備中……';
    const send=document.createElement('button');send.dataset.gaSubmit='';send.textContent='確認上傳這個範圍';send.hidden=true;
    send.addEventListener('click',()=>bulkSubmitRange(b));
    const cancel=document.createElement('button');cancel.dataset.gaCancel='';cancel.textContent='取消／停止';
    cancel.addEventListener('click',()=>{
      if(b.phase==='finished'){pane.remove();style.remove();return;}
      b.cancelled=true;bulkDetachSelection(b);
      if(b.phase==='choosing'||b.phase==='selected')bulkFinish(b,'已取消範圍選取，未上傳任何訊息。');
      else bulkStatus(b,'正在停止；已經成功上傳的訊息不會被撤回。',{force:true});
    });
    pane.append(title,caption,status,send,cancel);
    document.body.appendChild(pane);
    b.pane=pane;
  }
  function bulkClearHighlights(){
    document.querySelectorAll('[data-ga-archive-hover],[data-ga-archive-selected]').forEach(n=>{
      n.removeAttribute('data-ga-archive-hover');n.removeAttribute('data-ga-archive-selected');
    });
  }
  function bulkDetachSelection(b,clear=true){
    if(b.selectionHandlers){
      for(const [type,handler,options] of b.selectionHandlers)document.removeEventListener(type,handler,options);
      b.selectionHandlers=[];
    }
    if(b.scrollHandler&&b.host){b.host.removeEventListener('scroll',b.scrollHandler);b.scrollHandler=null;}
    if(clear)bulkClearHighlights();
  }
  function bulkEntry(target,preferEnd){
    const turn=target?.closest?.(BULK_SELECTOR);
    if(!turn)return null;
    const candidates=collect().filter(m=>bulkTurn(m)===turn&&bulkIdentity(m));
    // The owner can contain the player and GPT; select the entire exchange.
    if(!candidates.length)return null;
    return (preferEnd?candidates.findLast(m=>m.role==='ai'):candidates.find(m=>m.role==='me'))
       ||(preferEnd?candidates.at(-1):candidates[0]);
  }
  // In continuous downward mode, the viewport gives the initial direction,
  // not a persistent DOM anchor. ChatGPT may virtualize/recycle earlier turns
  // as soon as the page scrolls or a timestamp menu opens.
  function bulkDownFirstIndex(live,host){
    // Sort visible messages by their REAL viewport position. DOM fallback
    // ancestors may otherwise make the apparent first message be GPT.
    const visible=live.map((m,i)=>({m,i,node:bulkNode(m)}))
      .filter(x=>x.node&&bulkVisible(x.m,host))
      .sort((a,b)=>a.node.getBoundingClientRect().top-b.node.getBoundingClientRect().top || a.i-b.i);
    if(!visible.length)return -1;
    const first=visible[0];
    if(first.m.role==='ai'){
      const partner=pairedIndex(live,first.i);
      if(partner>=0 && live[partner].role==='me' && bulkIdentity(live[partner]))return partner;
      return -2; // Do not skip a GPT turn or silently start at later user text.
    }
    return bulkIdentity(first.m)?first.i:-1;
  }
  // Cross-window continuity is mandatory. A virtualized ChatGPT page may
  // unload all prior turns while scrolling; accepting the next DOM batch as
  // a continuation silently drops entire user+GPT pairs.
  function bulkCheckContinuity(b,live){
    if(!b.started||!b.rows.length)return {ok:true,lastKnown:-1};
    const known=[];
    for(let i=0;i<live.length;i++){
      const key=bulkIdentity(live[i]);
      if(key&&b.byKey.has(key))known.push(i);
    }
    if(!known.length)return {ok:false,error:'新畫面與上一批沒有共同訊息；可能已跳過整段對話'};
    const first=known[0],last=known.at(-1);
    // New DOM turns before an old anchor signal missed text, not history to skip.
    if(live.slice(0,first).some(m=>{const k=bulkIdentity(m);return k&&!b.byKey.has(k)}))
      return {ok:false,error:'有未記錄的訊息出現在接續錨點之前，可能漏掃'};
    const tail=b.rows.at(-1)?.bulkKey;
    const newAfter=live.slice(last+1).some(m=>{const k=bulkIdentity(m);return k&&!b.byKey.has(k)});
    if(newAfter&&!live.some(m=>bulkIdentity(m)===tail))
      return {ok:false,error:'上一批最後一則已離開畫面，無法確認新訊息緊接在後'};
    return {ok:true,lastKnown:last};
  }
  function bulkRoleIssue(rows){
    for(let i=0;i<rows.length;i++){
      const expected=i%2===0?'me':'ai';
      if(rows[i].role!==expected)return i%2===0
        ?'第 '+(i+1)+' 則是 GPT，但前面沒有對應皮卡發言'
        :'第 '+(i+1)+' 則是皮卡，但前面一則皮卡尚未有 GPT 回覆';
    }
    return '';
  }
  function bulkHarvest(b){
    const live=collect();
    let idx=-1;
    if(b.mode==='down'){
      if(!b.started){
        idx=bulkDownFirstIndex(live,b.host);
        if(idx===-2){b.startProblem='目前畫面第一則是 GPT 回覆，但沒有能驗證的前置皮卡訊息；請往上捲到這組皮卡發言再開始，禁止從 GPT 開頭';return false;}
        if(idx>=0){
          if(live[idx].role!=='me'){b.startProblem='起點未通過角色驗證：第一則必須是皮卡，不允許 GPT 先出現';return false;}
          b.started=true;
          // This is a one-time order hint, NOT an anchor we must find again.
          b.baseOrder=Math.max(0,idx);
        }
      }else{
        const check=bulkCheckContinuity(b,live);
        if(!check.ok){b.gapError=check.error;return false;}
        b.gapError='';
        idx=check.lastKnown+1;
      }
    }else{
      // Manual range mode alone must retain and re-find its chosen start.
      const anchor=live.findIndex(m=>bulkIdentity(m)===b.startKey);
      idx=anchor;
      if(idx<0&&b.started){
        const check=bulkCheckContinuity(b,live);
        if(!check.ok){b.gapError=check.error;return false;}
        b.gapError='';
        idx=check.lastKnown+1;
      }
    }
    if(idx<0)return false;
    b.started=true;
    if(!b.rows.length && live[idx]?.role!=='me'){b.startProblem='掃描的第一則不是皮卡，已中止且本批不傳送';return false;}
    for(let i=0;i<live.length;i++){
      const m=live[i],key=bulkIdentity(m);
      const previous=key?b.byKey.get(key):null;
      // Refresh earlier seen messages (expanded text or captured menu time),
      // but NEVER introduce new items before the starting/continuation index.
      if(i<idx&&!previous)continue;
      if(!key){
        if(i>=idx)b.badIdentity=true;
        continue;
      }
      const collapsed=isCollapsed(m);
      const snapshot={...m,bulkKey:key,id:bulkSendIdentity({...m,bulkKey:key}),collapsed};
      if(previous){
        // Stable message keys must not be recycled for a different message.
        // Expanding folded text may grow a prefix, but unrelated text is a
        // conflict and must halt the entire upload.
        if(!previous.collapsed&&!snapshot.collapsed&&previous.text!==snapshot.text&&
          !snapshot.text.startsWith(previous.text)&&!previous.text.startsWith(snapshot.text)){
          b.identityConflict='相同訊息 ID 讀到不同內容（'+key+'），可能遇到虛擬列表重用；禁止上傳';
          return false;
        }
        if(!collapsed&&(previous.collapsed||snapshot.text.length>=previous.text.length)){
          previous.text=snapshot.text;previous.collapsed=false;
        }
        if(snapshot.sourceCreatedAt&&(!previous.sourceCreatedAt||
          (snapshot.sourceTimeOrigin==='menu'&&previous.sourceTimeOrigin!=='menu'))){
          previous.sourceCreatedAt=snapshot.sourceCreatedAt;
          previous.sourceTimeOrigin=snapshot.sourceTimeOrigin;
          previous.sourceTimePrecision=snapshot.sourceTimePrecision;
        }
      }else{
        b.byKey.set(key,snapshot);b.rows.push(snapshot);
      }
    }
    return true;
  }
  // Check text again after each click. In Chrome, controls can be rendered but